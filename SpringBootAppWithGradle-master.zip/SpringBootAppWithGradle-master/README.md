# SpringBootAppWithGradle

Right-click on the project and Run the application as Spring Boot App -

http://localhost:8080/